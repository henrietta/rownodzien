# coding=UTF-8
from django.db import models

class Wpis(models.Model):
    tresc = models.TextField(verbose_name=u'Treść')
    email = models.EmailField(max_length=256, verbose_name=u'E-mail')
    nick = models.CharField(max_length=30, verbose_name=u'Nick')    
    kiedy = models.DateTimeField(auto_now_add=True, verbose_name=u'Kiedy dodano')
