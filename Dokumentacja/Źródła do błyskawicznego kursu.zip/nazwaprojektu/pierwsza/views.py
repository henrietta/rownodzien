# coding=UTF-8
from django.shortcuts import render_to_response
from datetime import datetime

def hello_world(request):
    data = datetime.now()
    return render_to_response('godzina.html', {'godzina': data})

from pierwsza.models import Wpis

def wszystkie(request):
    wpisy = Wpis.objects.all()
    return render_to_response('wszystkie.html', {'wpisy': wpisy})    

from django import forms
from django.shortcuts import redirect

class DodajWpis(forms.ModelForm):
    class Meta:
        model = Wpis
        exclude = ['kiedy']

def dodaj(request):
    if request.method == 'POST':
        form = DodajWpis(request.POST)
        if form.is_valid():
            form.instance.save()
            return redirect('/wpisy/')
    else:
        form = DodajWpis()

    return render_to_response('dodaj.html', {'form': form})
