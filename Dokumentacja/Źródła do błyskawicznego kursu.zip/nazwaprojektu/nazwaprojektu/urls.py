from django.conf.urls import patterns, include, url

urlpatterns = patterns('',
    url(r'^hello/', 'pierwsza.views.hello_world'),
    url(r'^wpisy/', 'pierwsza.views.wszystkie'),
    url(r'^dodaj/', 'pierwsza.views.dodaj'),
)
